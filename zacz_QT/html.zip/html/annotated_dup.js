var annotated_dup =
[
    [ "Ui", null, [
      [ "MainWindow", "classUi_1_1MainWindow.html", null ]
    ] ],
    [ "MainWindow", "classMainWindow.html", "classMainWindow" ],
    [ "Ui_MainWindow", "classUi__MainWindow.html", null ]
];