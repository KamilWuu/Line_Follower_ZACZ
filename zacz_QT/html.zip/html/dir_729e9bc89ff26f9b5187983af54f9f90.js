var dir_729e9bc89ff26f9b5187983af54f9f90 =
[
    [ "Desktop_Qt_6_7_0-Debug", "dir_914c8666dc9ef6d58a30f5c06451fe84.html", "dir_914c8666dc9ef6d58a30f5c06451fe84" ]
];