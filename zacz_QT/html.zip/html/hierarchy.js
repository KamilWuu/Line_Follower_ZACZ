var hierarchy =
[
    [ "QMainWindow", null, [
      [ "MainWindow", "classMainWindow.html", null ]
    ] ],
    [ "Ui_MainWindow", "classUi__MainWindow.html", [
      [ "Ui::MainWindow", "classUi_1_1MainWindow.html", null ]
    ] ]
];